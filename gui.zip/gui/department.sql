-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 09:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `department`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentsmgmnt`
--

CREATE TABLE `studentsmgmnt` (
  `name` varchar(10) DEFAULT NULL,
  `regno` varchar(20) DEFAULT NULL,
  `math` int(11) DEFAULT NULL,
  `java` int(11) DEFAULT NULL,
  `php` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentsmgmnt`
--

INSERT INTO `studentsmgmnt` (`name`, `regno`, `math`, `java`, `php`) VALUES
('Rosette', '22RP01965', 100, 100, 100),
('Rrr', '22222', 90, 67, 45),
('Rosette', '22rp0098', 90, 98, 1),
('Ishimwe', '22RP01965', 67, 87, 95),
('rr', '2', 3, 3, 3),
('vv', '8', 9, 10, 12),
('Hortance', '22RP03242', 45, 67, 78),
('Gael', '22RP02166', 32, 32, 32);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
